//
//  PostsViewModel.swift
//  LeagueMobileChallenge
//
//  Created by RAMESHUZ on 10/08/24.
//  Copyright © 2024 Kelvin Lau. All rights reserved.
//

import Foundation
class PostsViewModel {
    @Published var message: String = ""
    @Published var posts = [Post]()
    @Published var isLoading: Bool = false

    var users = [User]()
    
    func fetchPosts() {
        loginUserAndGetPosts()
    }
    
    private func loginUserAndGetPosts() {
        self.isLoading = true
        APIController.shared.fetchUserToken { [weak self] token, error in
            self!.isLoading = false
            guard let self else { return }
            if error == nil {
                self.getUserInfo()
                self.getAllPosts()
            } else {
                self.message = error?.localizedDescription ?? "Something worng with server"
            }
        }
    }
    private func getUserInfo() {
        self.isLoading = true
        APIController.shared.fetchUsers { users, error in
            self.isLoading = false
            if error == nil {
                if let users = users as? [User] {
                    self.users.append(contentsOf: users)
                }
            } else {
                self.message = error?.localizedDescription ?? "Something worng with server"
            }
        }
    }
    private func getAllPosts() {
        self.isLoading = true
        APIController.shared.fetchPosts { posts, error in
            self.isLoading = false
            if error == nil {
                if let postsFetched = posts as? [Post] {
                    //self.posts.append(contentsOf: postsFetched)
                    self.posts = postsFetched
                }
            } else {
                self.message = error?.localizedDescription ?? "Something worng with server"
            }
        }
    }
    func getUserInfo(userId: Int) -> (String, String)? {
        if let user = users.filter({ $0.id == userId }).first {
            return (user.name, user.avatar)
        }
        return nil
    }
}
