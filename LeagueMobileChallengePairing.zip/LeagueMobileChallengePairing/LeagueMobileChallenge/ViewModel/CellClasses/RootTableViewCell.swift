//
//  RootTableViewCell.swift
//  LeagueMobileChallenge
//
//  Created by RAMESHUZ on 10/08/24.
//  Copyright © 2024 Kelvin Lau. All rights reserved.
//

import UIKit
import SDWebImage

class RootTableViewCell: UITableViewCell {

    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var postTitleLabel: UILabel!
    @IBOutlet weak var postDescriptionLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        avatarImageView.layer.cornerRadius = avatarImageView.frame.height/2
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

    func configureCell(post:Post) {
        self.postTitleLabel.text = post.title
        self.postDescriptionLabel.text = post.body
    }
    
    func configureAvatar(name:String, avtar:String) {
        self.userNameLabel.text = name
        self.avatarImageView.sd_setImage(with: URL(string: avtar))
        self.avatarImageView.sd_setImage(with: URL(string: avtar), placeholderImage: UIImage(named: "user.png"))
    }
}
