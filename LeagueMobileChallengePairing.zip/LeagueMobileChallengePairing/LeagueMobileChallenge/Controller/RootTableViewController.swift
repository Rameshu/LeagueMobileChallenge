//
//  RootTableViewController.swift
//  LeagueMobileChallenge
//
//  Created by RAMESHUZ on 10/08/24.
//  Copyright © 2024 Kelvin Lau. All rights reserved.
//

import UIKit
import Combine
class RootTableViewController: UITableViewController {

    private var viewModel = PostsViewModel()
    private var cancellabe = Set<AnyCancellable>()
    private var activityIndicator: UIActivityIndicatorView!

    // MARK: - View DidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.estimatedRowHeight = 100
        tableView.tableFooterView = UIView(frame: .zero)
        configureActivityIndicator()
        viewModel.fetchPosts()
        viewModel.$posts
            .receive(on: DispatchQueue.main)
            .sink { [weak self] posts in
            self?.tableView.reloadData()
        }
        .store(in: &cancellabe)
                        
        viewModel.$isLoading
            .receive(on: RunLoop.main)
            .sink { [weak self] isLoading in
                if isLoading {
                    self?.startLoading()
                } else {
                    self?.stopLoading()
                }
            }
            .store(in: &cancellabe)
        
        viewModel.$message.dropFirst().sink { message in
            self.showAlertWithMessage(message)
        }
        .store(in: &cancellabe)
    }
    
    func configureActivityIndicator() {
        // Create and configure the activity indicator
        activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator.color = .gray
        activityIndicator.center = view.center
        activityIndicator.hidesWhenStopped = true
        // Add the activity indicator to the view
        view.addSubview(activityIndicator)
        startLoading()
    }
    
    func startLoading() {
        // Show and start animating the activity indicator
        activityIndicator.startAnimating()
    }

    func stopLoading() {
        // Stop animating and hide the activity indicator
        activityIndicator.stopAnimating()
    }
    
    // Show alert message
    func showAlertWithMessage(_ message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: { action in
        })
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }

    // MARK: - Table view data source and delegate
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.posts.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath) as? RootTableViewCell
        let post = viewModel.posts[indexPath.row]
        // Configure the cell...
        cell?.configureCell(post: post)
        if let userInfo = viewModel.getUserInfo(userId: post.userID) {
            cell?.configureAvatar(name: userInfo.0, avtar: userInfo.1)
        }

        return cell!
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
