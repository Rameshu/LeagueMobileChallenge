//
//  Post.swift
//  LeagueMobileChallenge
//
//  Created by RAMESHUZ on 10/08/24.
//  Copyright © 2024 Kelvin Lau. All rights reserved.
//

import Foundation
struct Post: Codable {
    let userID, id: Int
    let title, body: String

    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case id, title, body
    }
}
