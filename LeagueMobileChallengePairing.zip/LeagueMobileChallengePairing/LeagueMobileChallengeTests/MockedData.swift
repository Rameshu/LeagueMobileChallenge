//
//  MockedData.swift
//  LeagueMobileChallengeTests
//
//  Created by RAMESHUZ on 11/08/24.
//  Copyright © 2024 Kelvin Lau. All rights reserved.
//

import Foundation
public final class MockedData {
    private static func jsonResource(_ name: String) -> URL {
        return Bundle(for: MockedData.self).url(forResource: name, withExtension: "json")!
    }
    
    public static let users = jsonResource("Users")
    public static let post = jsonResource("Posts")

}
