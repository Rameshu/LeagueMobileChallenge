//
//  LeagueMobileChallengeTests.swift
//  LeagueMobileChallengeTests
//
//  Created by Kelvin Lau on 2019-01-09.
//  Copyright © 2019 Kelvin Lau. All rights reserved.
//

import XCTest
import Combine

@testable import LeagueMobileChallenge

class LeagueMobileChallengeTests: XCTestCase {
    
    var viewModel: PostsViewModel!
    var cancellables: Set<AnyCancellable>!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        viewModel = PostsViewModel()
        cancellables = []
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        viewModel = nil
        cancellables = nil
    }

    // Test
    func testFetchPosts() {
       let expectation = XCTestExpectation(description: "Fetch posts successfully")
        guard let posts = parseJSON(filename: "Post", modelType: Post.self) else {
            return
        }
        APIController.shared = MockAPIController(mockPosts: posts, mockUsers: nil, token: "ADF7846A45FA75BA2CCD6C8E980D5CDF", shouldFail: false)
       
       viewModel.$posts
           .dropFirst()
           .sink { posts in
               // Assert
               XCTAssertEqual(posts.count, posts.count, "The number of posts are equal")
               expectation.fulfill()
           }
           .store(in: &cancellables)
       
       viewModel.fetchPosts()
       
       wait(for: [expectation], timeout: 5.0)
   }
        
    func testGetUserInfo() {
        guard let mockUsers = parseJSON(filename: "Users", modelType: User.self) else {
            return
        }
        viewModel.users = mockUsers
        let userInfo = viewModel.getUserInfo(userId: 1)
        // Assert
        XCTAssertNotNil(userInfo, "User info should not be nil for a valid user Id")
        XCTAssertEqual(userInfo?.0, "Leanne Graham", "User name matched")
        XCTAssertEqual(userInfo?.1, "https://i.pravatar.cc/150?u=Sincere@april.biz", "User avatar is matching")
    }

    // Function to load JSON data from a file in the bundle
    func loadJSONFromFile(filename: String) -> Data? {
        let bundle = Bundle(for: type(of: self))
        if let url = bundle.url(forResource: filename, withExtension: "json") {
            return try? Data(contentsOf: url)
        }
        return nil
    }
    
    // Generic function to convert JSON data to model array
    func parseJSON<T: Decodable>(filename: String, modelType: T.Type) -> [T]? {
        guard let jsonData = loadJSONFromFile(filename: filename) else {
            return nil
        }
        do {
            let modelArray = try JSONDecoder().decode([T].self, from: jsonData)
            return modelArray
        } catch {
            debugPrint("Error decoding JSON: \(error)")
            return nil
        }
    }
}
