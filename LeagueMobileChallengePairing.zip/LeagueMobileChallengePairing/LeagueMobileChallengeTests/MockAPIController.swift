//
//  PostsViewModelTests.swift
//  LeagueMobileChallengeTests
//
//  Created by RAMESHUZ on 11/08/24.
//  Copyright © 2024 Kelvin Lau. All rights reserved.
//

import XCTest
import Combine

@testable import LeagueMobileChallenge


// Mock APIController to simulate network responses
class MockAPIController: APIController {
    private var mockPosts: [Post]?
    private var mockUsers: [User]?
    private var token: String?
    private var shouldFail: Bool

    init(mockPosts: [Post]?, mockUsers: [User]?, token: String?, shouldFail: Bool) {
        self.mockPosts = mockPosts
        self.mockUsers = mockUsers
        self.token = token
        self.shouldFail = shouldFail
    }

    func fetchUserToken(completion: @escaping (String?, Error?) -> Void) {
        if shouldFail {
            completion(nil, NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Something worng with server"]))
        } else {
            completion(token, nil)
        }
    }

    func fetchUsers(completion: @escaping ([User]?, Error?) -> Void) {
        if shouldFail {
            completion(nil, NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Something worng with server"]))
        } else {
            completion(mockUsers, nil)
        }
    }

    func fetchPosts(completion: @escaping ([Post]?, Error?) -> Void) {
        if shouldFail {
            completion(nil, NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Something worng with server"]))
        } else {
            completion(mockPosts, nil)
        }
    }
}
